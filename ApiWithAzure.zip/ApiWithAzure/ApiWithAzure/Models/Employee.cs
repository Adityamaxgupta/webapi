﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.Storage.Table;

namespace ApiWithAzure.Models
{
    public class Employee:TableEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
        public DateTime DOJ { get; set; }
        public string Department { get; set; }

        public Employee(string Department,int Id)
        {
            this.PartitionKey = Department;
            this.RowKey =  Id.ToString();
        }

        public Employee()
        {

        }
    }
}