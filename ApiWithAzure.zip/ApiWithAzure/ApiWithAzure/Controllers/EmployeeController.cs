﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ApiWithAzure.Models;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage;

namespace ApiWithAzure.Controllers
{
    public class EmployeeController : ApiController
    {
        static CloudStorageAccount storageAccount = null;
        static CloudTableClient tableClient = null;
        static CloudTable table = null;

        static List<Employee> emps = new List<Employee>();

        public EmployeeController()
        {
            storageAccount = CloudStorageAccount.Parse(Microsoft.Azure.CloudConfigurationManager.GetSetting("StorageConnectionString"));
            tableClient = storageAccount.CreateCloudTableClient();
            table = tableClient.GetTableReference("Employee");
            table.CreateIfNotExists();
        

        }

        public void Post(Employee employee)
        {
            Employee emp = new Employee(employee.Department, employee.Id);
            emp.Name = employee.Name;
            emp.DOJ = employee.DOJ;
            emp.Salary = employee.Salary;
            emp.Id = employee.Id;
            emp.Department = employee.Department;
            TableOperation tableOperation = TableOperation.Insert(emp);
            table.Execute(tableOperation);
        }

        public IEnumerable<Employee> Get()
        {
            List<Employee> emps = new List<Employee>();
            TableQuery<Employee> query = new TableQuery<Employee>();
            foreach (Employee e in table.ExecuteQuery(query))
            {
                Employee emp = new Employee
                {
                    Id = int.Parse(e.RowKey),
                    Name = e.Name,
                    Department = e.PartitionKey,
                    DOJ = e.DOJ,
                    Salary = e.Salary
                };
                emps.Add(emp);
            }
            return emps;
        }

        public Employee GetEmployee(String pk, String rk)
        {
            TableOperation tableOperation = TableOperation.Retrieve<Employee>(pk, rk);
            TableResult tableResult = table.Execute(tableOperation);
            Employee emp = null;
            if (tableResult.Result != null)
            {
                emp = tableResult.Result as Employee;
            }
            return emp;
        }
    }
}
